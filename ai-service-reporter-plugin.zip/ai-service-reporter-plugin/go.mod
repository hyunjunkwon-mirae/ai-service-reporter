module github.com/miraeasset/ai-service-reporter-plugin

go 1.21

require (
	github.com/gorilla/mux v1.8.1
	github.com/lib/pq v1.10.9
	github.com/mattermost/mattermost/server/public v0.1.10
	github.com/matoous/go-nanoid/v2 v2.1.0
	github.com/pkg/errors v0.9.1
)
